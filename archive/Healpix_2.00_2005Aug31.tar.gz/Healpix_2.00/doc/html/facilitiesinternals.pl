# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/fac:ud_grade/;
$ref_files{$key} = "$dir".q|facilitiesnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:synfast/;
$ref_files{$key} = "$dir".q|facilitiesnode11.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:map2gif/;
$ref_files{$key} = "$dir".q|facilitiesnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/page:defdir/;
$ref_files{$key} = "$dir".q|facilitiesnode2.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:plmgen/;
$ref_files{$key} = "$dir".q|facilitiesnode9.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:smoothing/;
$ref_files{$key} = "$dir".q|facilitiesnode10.htm|; 
$noresave{$key} = "$nosave";

$key = q/eq:alteralm/;
$ref_files{$key} = "$dir".q|facilitiesnode4.htm|; 
$noresave{$key} = "$nosave";

$key = q/section:defdir/;
$ref_files{$key} = "$dir".q|facilitiesnode2.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:hotspot/;
$ref_files{$key} = "$dir".q|facilitiesnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:median_filter/;
$ref_files{$key} = "$dir".q|facilitiesnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/page:ioprec/;
$ref_files{$key} = "$dir".q|facilitiesnode2.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:alteralm/;
$ref_files{$key} = "$dir".q|facilitiesnode4.htm|; 
$noresave{$key} = "$nosave";

$key = q/fac:anafast/;
$ref_files{$key} = "$dir".q|facilitiesnode5.htm|; 
$noresave{$key} = "$nosave";

1;

