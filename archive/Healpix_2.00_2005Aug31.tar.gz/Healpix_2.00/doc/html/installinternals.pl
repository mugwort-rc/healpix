# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/section:newfeatures/;
$ref_files{$key} = "$dir".q|installnode19.htm|; 
$noresave{$key} = "$nosave";

$key = q/section:requirements/;
$ref_files{$key} = "$dir".q|installnode3.htm|; 
$noresave{$key} = "$nosave";

$key = q/dirtree/;
$ref_files{$key} = "$dir".q|installnode2.htm|; 
$noresave{$key} = "$nosave";

$key = q/sec:troubleshoot/;
$ref_files{$key} = "$dir".q|installnode11.htm|; 
$noresave{$key} = "$nosave";

1;

