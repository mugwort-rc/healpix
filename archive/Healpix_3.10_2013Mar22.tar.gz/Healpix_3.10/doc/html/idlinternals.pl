# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/idl:remove_dipole:coord_out/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:complex/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:ordering/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:noposition/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:show/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:healpix_doc/;
$ref_files{$key} = "$dir".q|idlnode29.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:out/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:write_fits_map/;
$ref_files{$key} = "$dir".q|idlnode67.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:select/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:init_healpix/;
$ref_files{$key} = "$dir".q|idlnode35.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:interactive/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:transparent/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:silent/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:pxsize/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:reso_arcmin/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:map_out/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:hist_equal/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:alm_vec/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:index/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:other_keywords/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:hole_arcmin2/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:no_dipole/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:lm2index/;
$ref_files{$key} = "$dir".q|idlnode39.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2fits/;
$ref_files{$key} = "$dir".q|idlnode15.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:hdr/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:help/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/page:example_hires_cutsky/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:factor/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:file/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_t2i:alm_table/;
$ref_files{$key} = "$dir".q|idlnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:map2_out/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:pysize/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:pxsize/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:vector0/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:nside/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:signal/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:planck1/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:radians/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:subtitle/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:nside2npix/;
$ref_files{$key} = "$dir".q|idlnode46.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:inclusive/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:beam/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:ring/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_strip/;
$ref_files{$key} = "$dir".q|idlnode53.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:template_pixel_xxx/;
$ref_files{$key} = "$dir".q|idlnode63.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:euler_matrix_new/;
$ref_files{$key} = "$dir".q|idlnode21.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:read_fits_s/;
$ref_files{$key} = "$dir".q|idlnode57.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:truecolors/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:charsize/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:nside/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:degrees/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:nside2ntemplates/;
$ref_files{$key} = "$dir".q|idlnode47.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:keep_tmp_files/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:write_fits_sb/;
$ref_files{$key} = "$dir".q|idlnode68.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:nested/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:w8dir/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:min/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:theta_cut_deg/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:lmax/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:tmpdir/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:polarization/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:help/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:neighbours_ring/;
$ref_files{$key} = "$dir".q|idlnode44.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:kml/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bin_llcl/;
$ref_files{$key} = "$dir".q|idlnode13.htm|; 
$noresave{$key} = "$nosave";

$key = q/fig:plot_visu/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_t2i:help/;
$ref_files{$key} = "$dir".q|idlnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_t2i/;
$ref_files{$key} = "$dir".q|idlnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam:radians/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ang2vec/;
$ref_files{$key} = "$dir".q|idlnode9.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:input_map/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:coord/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:example/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:xhdr/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:jpeg/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:order_in/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:w8file/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:orthview/;
$ref_files{$key} = "$dir".q|idlnode49.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:arcmin/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:reso_arcmin/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:png/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:shaded/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:monopole/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:gnomcursor/;
$ref_files{$key} = "$dir".q|idlnode27.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_triangle/;
$ref_files{$key} = "$dir".q|idlnode54.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:ring/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:idlxxx/;
$ref_files{$key} = "$dir".q|idl.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:ps/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:index2lm/;
$ref_files{$key} = "$dir".q|idlnode34.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:order_out/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam:degrees/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:png/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/fig:merge_wmapKband/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:keep_tmp_files/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:iglsize/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:igraticule/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:write_fits_cut4/;
$ref_files{$key} = "$dir".q|idlnode66.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:lmax/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:execute/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:log/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:xhdr/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:angulardistance:v/;
$ref_files{$key} = "$dir".q|idlnode10.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:units/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:multipoles/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollcursor/;
$ref_files{$key} = "$dir".q|idlnode41.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:isynfast/;
$ref_files{$key} = "$dir".q|idlnode38.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:theta/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam:theta/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:titleplot/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:angulardistance:w/;
$ref_files{$key} = "$dir".q|idlnode10.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:pix_tools/;
$ref_files{$key} = "$dir".q|idlnode50.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:help/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:file/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:ordering/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/page:plot_visu/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:save/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:offset/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:map_out/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:help/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:write_tqu/;
$ref_files{$key} = "$dir".q|idlnode69.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:window/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:fits/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:coord_in/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:colt/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:weight/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:n2r/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:nested/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:read_fits_map/;
$ref_files{$key} = "$dir".q|idlnode56.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:bad_data/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:nested/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:hbound/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:nside_out/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:half_sky/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:rotate_coord/;
$ref_files{$key} = "$dir".q|idlnode61.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:glsize/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits:xhdr/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:orthcursor/;
$ref_files{$key} = "$dir".q|idlnode48.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:cartview/;
$ref_files{$key} = "$dir".q|idlnode17.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:rshow/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:iter_order/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam:bl/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:tmpdir/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:help/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:alm_array/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:radius/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:lmax/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:deg/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:units/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:pessimistic/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:nested/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:npix2nside/;
$ref_files{$key} = "$dir".q|idlnode45.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:rot/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:extension/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:cartcursor/;
$ref_files{$key} = "$dir".q|idlnode16.htm|; 
$noresave{$key} = "$nosave";

$key = q/page:merge_wmapKband/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:nolabels/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits:help/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:beam_file/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:jpeg/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam:help/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:select/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:asinh/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:healpixwindow/;
$ref_files{$key} = "$dir".q|idlnode30.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:won/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits:fitsfile/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:pixel/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:hxsize/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:angulardistance/;
$ref_files{$key} = "$dir".q|idlnode10.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:nlist/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:wmap7/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:gal_cut/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:binpath/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:regression/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:map/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:gaussbeam/;
$ref_files{$key} = "$dir".q|idlnode24.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:filled_mask/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_polygon/;
$ref_files{$key} = "$dir".q|idlnode52.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:map1_in/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:preview/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:charthick/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:distance_map/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:hdr/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:silent/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:file/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:coord_in/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:r2n/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:neighbours_nest/;
$ref_files{$key} = "$dir".q|idlnode43.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:median_filter/;
$ref_files{$key} = "$dir".q|idlnode40.htm|; 
$noresave{$key} = "$nosave";

$key = q/page:plot_example_execute/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:graticule/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:help/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:change_polcconv/;
$ref_files{$key} = "$dir".q|idlnode18.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits:hdr/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2gs:help/;
$ref_files{$key} = "$dir".q|idlnode32.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:max/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:bl2beam:arcmin/;
$ref_files{$key} = "$dir".q|idlnode14.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:silent/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:fwhm_arcmin/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:mask_in/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:map_in/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:bad_data/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits:index/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:silent/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:dipole/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:in/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:fitsfile/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:ypos/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:preview/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:gnomview/;
$ref_files{$key} = "$dir".q|idlnode28.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:simul_type/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:cl_array/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:help/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:crop/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:silent/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:gif/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:angulardistance:help/;
$ref_files{$key} = "$dir".q|idlnode10.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ianafast/;
$ref_files{$key} = "$dir".q|idlnode33.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:retain/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:mmax/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:outline/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:query_disc:listpix/;
$ref_files{$key} = "$dir".q|idlnode51.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:subtitle/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:binpath/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ud_grade:help/;
$ref_files{$key} = "$dir".q|idlnode64.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:same_shape_pixels_xxx/;
$ref_files{$key} = "$dir".q|idlnode62.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:noremove/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:hpx2dm:other_keywords/;
$ref_files{$key} = "$dir".q|idlnode31.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:wmap5/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:plmfile/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_t2i:index/;
$ref_files{$key} = "$dir".q|idlnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/fig:plot_example_execute/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:getdisc_ring/;
$ref_files{$key} = "$dir".q|idlnode25.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:xpos/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:read_tqu/;
$ref_files{$key} = "$dir".q|idlnode58.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:azeqview/;
$ref_files{$key} = "$dir".q|idlnode11.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:stagger/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:wmap1/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:fitsfile/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:llfactor/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm:lmin/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:onlymonopole/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:png/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:gal_cut/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:nobar/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:help/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:titleplot/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:no_monopole/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:cl2fits/;
$ref_files{$key} = "$dir".q|idlnode19.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2cl:help/;
$ref_files{$key} = "$dir".q|idlnode23.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:vec2ang/;
$ref_files{$key} = "$dir".q|idlnode65.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:index/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:flip/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:covariance_matrix/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:fits2alm/;
$ref_files{$key} = "$dir".q|idlnode22.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_i2t:lmax/;
$ref_files{$key} = "$dir".q|idlnode6.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm2fits:alm_array/;
$ref_files{$key} = "$dir".q|idlnode8.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_t2i:alm_vec/;
$ref_files{$key} = "$dir".q|idlnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:getsize_fits/;
$ref_files{$key} = "$dir".q|idlnode26.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:TOP/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:mollview:select/;
$ref_files{$key} = "$dir".q|idlnode42.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:beam2bl:help/;
$ref_files{$key} = "$dir".q|idlnode12.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:convert_oldhpx2cmbfast/;
$ref_files{$key} = "$dir".q|idlnode20.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:ismoothing:double/;
$ref_files{$key} = "$dir".q|idlnode37.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:reorder:result/;
$ref_files{$key} = "$dir".q|idlnode60.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:alm_t2i:mfirst/;
$ref_files{$key} = "$dir".q|idlnode7.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:read_fits_cut4/;
$ref_files{$key} = "$dir".q|idlnode55.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:iprocess_mask:hole_pixels/;
$ref_files{$key} = "$dir".q|idlnode36.htm|; 
$noresave{$key} = "$nosave";

$key = q/idl:remove_dipole:ordering/;
$ref_files{$key} = "$dir".q|idlnode59.htm|; 
$noresave{$key} = "$nosave";

1;

