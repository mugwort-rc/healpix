#ifndef CHOPST_H
#define CHOPST_H

char *chopst (char *s, int n);

#endif
